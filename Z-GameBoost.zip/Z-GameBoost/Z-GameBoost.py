import tkinter as tk
from tkinter import messagebox
import subprocess
import shutil
import os

def optimize_game_performance():
    try:
        # Oyun performansını optimize etmek için yapılacak işlemleri buraya ekleyin
        # Bu kısım tamamen belirli bir oyun ve optimizasyon yöntemine bağlı olacaktır.
        print("Oyun performansı optimize ediliyor...")
    except Exception as e:
        messagebox.showerror("Hata", f"Bir hata oluştu: {str(e)}")

def clear_temp_folder():
    try:
        temp_path = os.path.join(os.environ["TEMP"])
        for file_name in os.listdir(temp_path):
            file_path = os.path.join(temp_path, file_name)
            try:
                if os.path.isfile(file_path):
                    os.unlink(file_path)
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
            except Exception as e:
                print(f"{file_path} silinemedi: {str(e)}")
                print("Bu hatayı almanız gayet normaldir. Lütfen bu konu hakkında iletişime geçmeyin!")

        messagebox.showinfo("Başarı", "Temp dosyaları temizlendi.")
    except Exception as e:
        messagebox.showerror("Hata", f"Bir hata oluştu: {str(e)}")
        print("Bu hatayı almanız gayet normaldir. Lütfen bu konu hakkında iletişime geçmeyin!")

def start_button_clicked():
    try:
        # Ping gönderme işlemi
        subprocess.run(["ping", "google.com"])

        # Oyun performansını optimize etme işlemi
        optimize_game_performance()

        # Temp dosyalarını temizleme işlemi
        clear_temp_folder()

        messagebox.showinfo("Başarı", "İşlemler başarıyla başlatıldı.")
    except Exception as e:
        messagebox.showerror("Hata", f"Bir hata oluştu: {str(e)}")

# Tkinter penceresini oluştur
window = tk.Tk()
window.title("Oyun Performans Scripti")

# Başlatma butonunu ekleyin
start_button = tk.Button(window, text="Başlat", command=start_button_clicked)
start_button.pack(pady=20)

# Pencereyi başlat
window.mainloop()
